import eli5
from eli5.sklearn import PermutationImportance, permutation_importance
import pandas as pd
import matplotlib.pyplot as plt
from untangleai.algorithms.eli5.explainer import Eli5Explain
import os
import jinja2

class PermutationImportances(Eli5Explain):
    '''
    An Implementation of ELI5 Permutation Importance for computing Permutation Importance/Feature Importances 
    for black box estimators.
    '''

    def __init__(self, model, X_test, y_test):
        '''
        Initilizing the Permutaion Importance object
        to fit on the Trained model object and test data
        '''
        self.X_test = X_test
        self.y_test = y_test
        super(PermutationImportances, self).__init__(model, self.X_test, self.y_test)
        self.perm = PermutationImportance(model, random_state=1).fit(self.X_test, self.y_test)

    def eli5_glbe(self, global_reports):
        weights = eli5.show_weights(self.perm, feature_names = self.X_test.columns.tolist()) 
        weights_data = weights.data
        eli5_path = os.path.join(global_reports, 'eli5')
        try: 
            os.mkdir(eli5_path) 
        except OSError as error: 
            pass
        weights_file_name = 'permutation_importance_weights.html'
        weights_file_path = os.path.join(eli5_path, weights_file_name)
        plot_file_name = 'permutation_importance_plot.png'
        plot_file_path = os.path.join(eli5_path, plot_file_name)
        with open(weights_file_path, 'w') as f:
            f.write(weights_data)
        fi = pd.Series(index = self.X_test.columns, data = self.perm.feature_importances_)
        pl = fi.sort_values(ascending=False)[0:20][::-1].plot(kind = 'barh')
        fi = fi.sort_values(ascending=False)
        fig = plt.gcf()
        fig.tight_layout(pad=2.0)
        pl.figure.savefig(plot_file_path, format='png', dpi=1000, bbox_inches='tight')
        plt.close("all")
        # template_path = os.path.join(os.getcwd(),'untangleai')
        # env = jinja2.Environment(loader=jinja2.FileSystemLoader(searchpath=template_path))
        # template = env.get_template('template.html')

        top = []
        least = []
        all_imp = []
        non_imp = []

        for i, each in fi.iteritems():
            if each > 0:
                all_imp.append(i)
            elif each<=0:
                non_imp.append(i)
        top = all_imp[0:5]
        least = non_imp[-5:]

        # top = ", ".join(top)
        # least = ", ".join(least)

        # html = template.render(most_imp=top, least_imp=least)

        # report_path = os.path.join(os.getcwd(),'reports','reports.html')
        # with open(report_path, 'w') as f:
        #     print('YAYYYYYYYYYYY')
        #     f.write(html)

        return top, least, all_imp


