import abc
import sys

if sys.version_info >= (3, 4):
    ABC = abc.ABC
else:
    ABC = abc.ABCMeta(str('ABC'), (), {})

class Eli5Explain(ABC):

    def __init__(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def eli5_glbe(self, *args, **kwargs):
        raise NoImplementationError

