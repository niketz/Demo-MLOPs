import yaml
import argparse

# config_path = "params.yaml"

def read_params(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
        return config


def get_data(config_path):
    config = read_params(config_path)
    model = config["estimators"]["models"]
    X_test = config["data_source"]["X_test"]
    y_test = config["data_source"]["y_test"]
    global_reports = config["reports"]["global"]
    return(model, X_test, y_test, global_reports)