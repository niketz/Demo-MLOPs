import matplotlib
import yaml
import argparse
import pickle
import pandas as pd
import matplotlib.pyplot as plt

import time
timestr = time.strftime("%Y%m%d-%H%M%S")

from untangleai.algorithms.eli5.eli5_wrapper import PermutationImportances
from untangleai.algorithms.eli5.get_data import get_data

def process_data(config_path):

    model, X_test, y_test, global_reports = get_data(config_path)

    # Loading necessary files for generating explanations
    model = pickle.load(open(model,'rb'))
    X_test = pd.read_csv(X_test)
    y_test = pd.read_csv(y_test)

    perm_imp = PermutationImportances(model=model, X_test=X_test, y_test=y_test)

    top, least, all_imp = perm_imp.eli5_glbe(global_reports)

    return top, least, all_imp

