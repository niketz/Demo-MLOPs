import yaml
import argparse

# config_path = "params.yaml"

def read_params(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
        return config

def get_data(config_path):
    config = read_params(config_path)
    model = config["estimators"]["models"]
    X = config["data_source"]["X"]
    y = config["data_source"]["y"]
    X_train = config["data_source"]["X_train"]
    y_train = config["data_source"]["y_train"]
    X_test = config["data_source"]["X_test"]
    y_test = config["data_source"]["y_test"]
    mode = config["estimators"]["mode"]
    return(model, X, y, X_train, y_train, X_test, y_test, mode)