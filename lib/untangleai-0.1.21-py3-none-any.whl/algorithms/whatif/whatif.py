import pickle
import pandas as pd
import numpy as np
from untangleai.algorithms.whatif.get_data import get_data

import json
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output,State
from dash_html_components.Div import Div
import plotly.express as px
import pandas as pd
import pickle
from plotly.offline import iplot

from sklearn.metrics import confusion_matrix

# external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

# app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

app = dash.Dash(__name__)

app.config['suppress_callback_exceptions'] = True

styles = {
    'pre': {
        'border': 'thin lightgrey solid',
        'overflowX': 'scroll'
    }
}

def whatif(model, X, y, X_train, y_train, X_test, y_test, mode):

    if mode=='classification':
        print('I am in whatif file')

        y_pred = model.predict_proba(X_test)

        df = X_test.copy()
        df[['class_0', 'class_1']] = y_pred
        df['target'] = y_test

        x = df['class_1']

        cols = df.columns[:-3]
        VARS = df.columns[:-3]

        # cm = confusion_matrix(y, model.predict(X))
        # print(cm)

        fig = px.scatter(df, x=x, color="target", hover_data=cols)
        fig.update_layout(clickmode='event+select')
        fig.update_traces(marker_size=20)

        app.layout = html.Div(
            children=[
                html.Div(className='row',
                        children=[
                            html.Div(className='four columns div-user-controls',
                                    children=[
                                        html.H2('FEATURE & FEATURE VALUES', style={'text-align': 'center'}),
                                        html.Div(id='input-label', children=[html.Label(_.upper(), style={'height':'22px','padding':'8px 20px 8px 5px','text-align':'right'}) for _ in cols], style={'width':'50%','float':'left'}),
                                        html.Div(id='container',children=[dcc.Input(
                                                    id="input_{}".format(_),
                                                    type="text",
                                                    value=None,
                                                    placeholder=_.upper(),
                                                )
                                                for _ in cols]
                                                +[html.Button('Predict',id='sub-but',n_clicks=0,style={'width':'110%','background-color':'#199a19','margin-bottom':'5rem','margin-top':'1rem'})],
                                                style={'width': '50%', 'float': 'left'},
                                                ),
                                    ]
                                    ),
                            html.Div(className='eight columns div-for-charts bg-grey',
                                    children=[html.Div(children=[
                                        html.H2('PREDICTION DETAILS'),
                                        html.Div(id='prob-label-1', children=[html.Label(_, style={'height':'22px','padding':'8px 20px 8px 5px','text-align':'right'}) for _ in ['OLD PROB FOR CLASS 1','NEW PROB FOR CLASS 1','DELTA CHANGE FOR CLASS 1']], style={'width': '25%', 'float': 'left'}),
                                            html.Div(id='id-1', children=[dcc.Input(id="old_prob_true",type="text",value=None, placeholder="OLD PROB TRUE")]+
                                            [dcc.Input(id="new_prob_true",type="text",value=None, placeholder="NEW PROB TRUE")]+
                                            [dcc.Input(id="prob_change_true",type="text",value=None, placeholder="CHANGE IN TURE PROB")],
                                            style={'width': '25%', 'float': 'left'}),
                                            html.Div(id='prob-label-0', children=[html.Label(_, style={'height':'22px','padding':'8px 20px 8px 5px','text-align':'right'}) for _ in ['OLD PROB FOR CLASS 0','NEW PROB FOR CLASS 0','DELTA CHANGE FOR CLASS 0']], style={'width': '25%', 'float': 'left'}),
                                            html.Div(id='id-0',children=[dcc.Input(id="old_prob_false",type="text",value=None, placeholder="OLD PROB FALSE")]+
                                            [dcc.Input(id="new_prob_false",type="text",value=None, placeholder="NEW PROB FALSE")]+
                                            [dcc.Input(id="prob_change_false",type="text",value=None, placeholder="CHANGE IN FALSE PROB")],
                                            style={'width': '25%', 'float': 'left'}),
                                    ], style={'padding-top': '25px', 'padding-bottom': '25px', 'text-align': 'center'})]+
                                    [html.H2('INTERACTIVE DATA PLOT', style={'text-align': 'center'}),
                                    dcc.Graph( id='basic-interactions', figure=fig, style={'padding-top': '10px'})]),
                        ])
            ]
        )

        @app.callback(
            [Output('container','children'),Output('basic-interactions','figure'),Output('old_prob_true','value'),Output('new_prob_true','value'),Output('prob_change_true','value'),Output('old_prob_false','value'),Output('new_prob_false','value'),Output('prob_change_false','value')],
            [Input('sub-but', 'n_clicks'),Input('basic-interactions','clickData'),Input('container','children')],
            [State('container','children'),State('sub-but', 'n_clicks')])
        def display_click_data(button_data,clickData,total_container,div_children,div_children1):
            global temp
            if type(clickData) is dict:
                val = clickData['points'][0]['customdata']
                i = clickData['points'][0]['y']
                for j in range(len(total_container)-1):
                    if button_data == 0:
                        total_container[j]['props']['value']=val[j]
                        temp = button_data
                    else:
                        if temp == button_data:
                            total_container[j]['props']['value']=val[j]
                for j in range(len(total_container)-1):
                    df.iloc[i,j] = total_container[j]['props']['value']
                if button_data > temp:
                    print("------OLD DATA----------")
                    print(df.iloc[i,-2])    
                    print(df.iloc[i,-3])    
                    old_prob_true = df.iloc[i,-2] 
                    old_prob_false = df.iloc[i,-3]
                    y_new_pred = model.predict_proba(df.iloc[i,:-3].values.reshape(1,-1))
                    y_new_hat = model.predict(df.iloc[i,:-3].values.reshape(1,-1)) 
                    df.iloc[[i],[-3]] = y_new_pred[0][0] 
                    df.iloc[[i],[-2]] = y_new_pred[0][1]
                    df.iloc[[i],[-1]] = y_new_hat
                    prob_change_true = round((y_new_pred[0][1] - old_prob_true), 2)
                    prob_change_false = round((y_new_pred[0][0] - old_prob_false), 2)
                    print("--------NEW DATA---------")
                    print(df.iloc[i,-2])    
                    print(df.iloc[i,-3])  
                    temp = temp + 1
                    figs = px.scatter(df, x="class_1", color="target", hover_data=cols)
                    figs.update_layout(clickmode='event+select')
                    figs.update_traces(marker_size=20)
                    return (total_container,figs,old_prob_true,y_new_pred[0][1],prob_change_true,old_prob_false,y_new_pred[0][0],prob_change_false) 
                else:
                    figs = px.scatter(df, x="class_1", color="target", hover_data=cols)
                    figs.update_layout(clickmode='event+select')
                    figs.update_traces(marker_size=20)
                    return (total_container,figs,df.iloc[i,-2],None,None,df.iloc[i,-3],None,None) 
            else:
                return(total_container,fig,None,None,None,None,None,None)
        
        app.run_server(debug=True)
    
    else:
        df = X_test.copy()
        df['pred'] = model.predict(X_test)
        df['target'] = y_test

        # print(df.head())

        x = df['pred']

        cols = df.columns[:-2]

        fig = px.scatter(df, x=x, color="target", hover_data=cols)

        fig.update_layout(clickmode='event+select')

        fig.update_traces(marker_size=20)

        # VARS = df.columns[:-3]

        app.layout = html.Div(
            children=[
                html.Div(className='row',
                        children=[
                            html.Div(className='four columns div-user-controls',
                                    children=[
                                        html.H2('FEATURE & FEATURE VALUES', style={'text-align': 'center'}),
                                        html.Div(id='input-label', children=[html.Label(_.upper(), style={'height':'22px','padding':'8px 20px 8px 5px','text-align':'right'}) for _ in cols], style={'width':'50%','float':'left'}),
                                        html.Div(id='container',children=[dcc.Input(
                                                    id="input_{}".format(_),
                                                    type="text",
                                                    value=None,
                                                    placeholder=_.upper(),
                                                )
                                                for _ in cols]
                                                +[html.Button('Predict',id='sub-but',n_clicks=0,style={'width':'110%','background-color':'#199a19','margin-bottom':'5rem','margin-top':'1rem'})],
                                                style={'width': '50%', 'float': 'left'},
                                                ),
                                    ]
                                    ),
                            html.Div(className='eight columns div-for-charts bg-grey',
                                    children=[html.Div(children=[
                                        html.H2('PREDICTION DETAILS'),
                                        html.Div(id='prob-label-1', children=[html.Label(_, style={'height':'22px','padding':'8px 20px 8px 5px','text-align':'right'}) for _ in ['OLD VALUE','NEW VALUE','DELTA CHANGE']], style={'width': '50%', 'float': 'left'}),
                                            html.Div(id='id-1', children=[dcc.Input(id="old_prob_true",type="text",value=None, placeholder="OLD VALUE")]+
                                            [dcc.Input(id="new_prob_true",type="text",value=None, placeholder="NEW VALUE")]+
                                            [dcc.Input(id="prob_change_true",type="text",value=None, placeholder="DELTA CHANGE")],
                                            style={'width': '25%', 'float': 'left'}),
                                    ], style={'padding-top': '25px', 'padding-bottom': '25px', 'text-align': 'center'})]+
                                    [html.H2('INTERACTIVE DATA PLOT', style={'text-align': 'center'}),
                                    dcc.Graph( id='basic-interactions', figure=fig, style={'padding-top': '10px'})]),
                        ])
            ]
        )

        @app.callback(
            [Output('container','children'),Output('basic-interactions','figure'),Output('old_prob_true','value'),Output('new_prob_true','value'),Output('prob_change_true','value')],
            [Input('sub-but', 'n_clicks'),Input('basic-interactions','clickData'),Input('container','children')],
            [State('container','children'),State('sub-but', 'n_clicks')])
        def display_click_data(button_data,clickData,total_container,div_children,div_children1):
            global temp
            if type(clickData) is dict:
                val = clickData['points'][0]['customdata']
                print(val)
                i = clickData['points'][0]['y']
                for j in range(len(total_container)-1):
                    if button_data == 0:
                        total_container[j]['props']['value']=val[j]
                        temp = button_data
                    else:
                        if temp == button_data:
                            total_container[j]['props']['value']=val[j]
                for j in range(len(total_container)-1):
                    df.iloc[i,j] = total_container[j]['props']['value']
                if button_data > temp:   
                    old_value = df.iloc[i,-1] 
                    new_value = model.predict(df.iloc[i,:-2].values.reshape(1,-1))[0]
                    delta_change =  new_value - old_value
                    print(old_value, new_value, delta_change)
                    df.iloc[[i],[-2]] = new_value
                    temp = temp + 1
                    figs = px.scatter(df, x="pred", color="pred", hover_data=cols)
                    figs.update_layout(clickmode='event+select')
                    figs.update_traces(marker_size=20)
                    return (total_container, figs, old_value, new_value, delta_change) 
                else:
                    figs = px.scatter(df, x="pred", color="pred", hover_data=cols)
                    figs.update_layout(clickmode='event+select')
                    figs.update_traces(marker_size=20)
                    return (total_container,figs,df.iloc[i,-1],None,None) 
            else:
                return(total_container,fig,None,None,None)
        
        app.run_server(debug=True)