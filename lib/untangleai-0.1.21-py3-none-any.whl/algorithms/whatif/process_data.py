import pickle
import pandas as pd
import numpy as np
from untangleai.algorithms.whatif.get_data import get_data
from untangleai.algorithms.whatif.whatif import whatif


def process_data(config_path):

    model, X, y, X_train, y_train, X_test, y_test, mode = get_data(config_path)

    # Loading necessary files for generating explanations
    model = pickle.load(open(model,'rb'))
    X = pd.read_csv(X)
    y = pd.read_csv(y)
    X_train = pd.read_csv(X_train)
    y_train = pd.read_csv(y_train)
    X_test = pd.read_csv(X_test)
    y_test = pd.read_csv(y_test)

    whatif(model, X, y, X_train, y_train, X_test, y_test, mode)