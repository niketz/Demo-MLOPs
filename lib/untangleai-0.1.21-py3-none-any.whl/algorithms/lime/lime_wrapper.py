from lime.lime_tabular import LimeTabularExplainer
from untangleai.algorithms.lime.explainer import LimeExplain
import os

class Lime(LimeExplain):
    '''
    param model : model object in pickle , .h5 format
    param mode : "classification" or "regression" 
    param X_train : pandas dataframe with all features used for training the model
    param y_train : pandas dataframe with output features used for training the model
    param X_test : pandas dataframe with all features used for testing the model
    '''

    def __init__(self, *args, **kwargs):
        pass

    @staticmethod
    def lime_loce(model, mode, X_train, y_train, X_test, rowid, class_names, local_reports):
        if mode == 'classification':
            predict_fn = lambda x: model.predict_proba(x).astype(float)
        elif mode == 'regression':
            predict_fn = lambda x: model.predict(x).reshape(1, -1)[0]
        else:
            print('Please provide a valid operation method i.e. either classification or regression')

        explainer = LimeTabularExplainer(X_train.astype(float).values,
                                        feature_names = X_train.columns,
                                        class_names = class_names,
                                        training_labels = y_train.columns[0],
                                        kernel_width=3,
                                        mode=mode
                                        )

        exp = explainer.explain_instance(X_test.iloc[rowid].astype(float).values, predict_fn, num_features=5)
        # exp.as_list()

        lime_path = os.path.join(local_reports, 'lime')
        try: 
            os.mkdir(lime_path) 
        except OSError as error: 
            pass
        filename = 'lime_exp_for_row_' + str(rowid) +'_.html'
        filepath = os.path.join(lime_path, filename)
        exp.save_to_file(filepath)
        return os.path.join('local', 'lime', filename)
        



