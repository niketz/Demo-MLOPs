from untangleai.algorithms.lime.lime_wrapper import Lime
from untangleai.algorithms.lime.get_data import get_data
import pandas as pd
import pickle

def process_data(config_path):
    model, mode, X_train, y_train, X_test, rowid, class_names, local_reports = get_data(config_path)
    model = pickle.load(open(model,'rb'))
    mode = mode
    X_train = pd.read_csv(X_train)
    y_train = pd.read_csv(y_train)
    X_test = pd.read_csv(X_test)
    row_list = rowid
    class_names = class_names
    
    lime_exp = Lime()

    limeplt_list = []

    for rowid in row_list:
        limefilepath = lime_exp.lime_loce(model, mode, X_train, y_train, X_test, rowid, class_names, local_reports)
        limeplt_list.append((limefilepath,rowid))
    
    return limeplt_list



