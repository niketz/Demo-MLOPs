import yaml

# config_path = "params.yaml"



def read_params(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
        return config


def get_data(config_path):
    config = read_params(config_path)
    model = config["estimators"]["models"]
    mode = config["estimators"]["mode"]
    X_train = config["data_source"]["X_train"]
    y_train = config["data_source"]["y_train"]
    X_test = config["data_source"]["X_test"]
    rowid = config["row_index_to_explain"]
    class_names = config["estimators"]["class_names"] 
    local_reports = config["reports"]["local"]
    return(model, mode, X_train, y_train, X_test, rowid, class_names, local_reports)