import shap
import sys, os
# print(sys.path.append(os.path.join(os.path.dirname(sys.path[0]))))
# print(sys.path)
from untangleai.algorithms.shap.explainer import Explain
import matplotlib.pyplot as plt
import PyPDF2
# from wrapper.explainer import Explain

class TreeExplainer(Explain):
    '''
    An implementation of Tree SHAP, a fast and exact algorithm to compute SHAP values for trees and ensembles of trees.
    This Explainer is be used for Tree Based Algorithms
    Some of the Supported Algorithms are as below -
    RandomForest
    DecisionTee
    LightGBM
    XGBoost
    CatBoost
    GradientBoostingClassifier
    and other tree based algorithm
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the TreeExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(TreeExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.TreeExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        # Method 1 - Saving as HTML
        # shap.save_html('reports/local/local_explainer.html', 
        #                 shap.force_plot(*args, *kwargs, show=False, matplotlib=False))
        #Method 2 - Saving as PDF
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, X_test, target_class, global_reports, algorithm):
        '''
        Global Plotting
        '''
        merger = PyPDF2.PdfFileMerger()

        shap_path = os.path.join(global_reports ,'shap', 'shap_temp')
        try:
            os.makedirs(shap_path)
        except OSError as error: 
            pass

        shap_values = self.explainer.shap_values(X_test)

        tgt_cls_file_name = 'explainer_tgt_cls_' + algorithm + '.pdf'
        tgt_cls_file_path = os.path.join(shap_path, tgt_cls_file_name)
        shap.summary_plot(shap_values[target_class], X_test, show=False)
        plt.savefig(tgt_cls_file_path, format='pdf', dpi=1000, bbox_inches='tight')
        merger.append(tgt_cls_file_path)
        plt.cla()

        tgt_cls_barplt_file_name = 'explainer_bar_plt_tgt_cls_' + algorithm + '.pdf'
        tgt_cls_barplt_file_path = os.path.join(shap_path, tgt_cls_barplt_file_name)
        shap.summary_plot(shap_values[target_class], X_test, plot_type="bar", show=False)
        plt.savefig(tgt_cls_barplt_file_path, format='pdf', dpi=1000, bbox_inches='tight')
        merger.append(tgt_cls_barplt_file_path)
        plt.cla()

        all_cls_barplt_file_name = 'explainer_bar_all_tgt_cls_' + algorithm + '.pdf'
        all_cls_barplt_file_path = os.path.join(shap_path, all_cls_barplt_file_name)
        shap.summary_plot(shap_values, X_test, plot_type="bar", show=False)
        plt.savefig(all_cls_barplt_file_path, format='pdf', dpi=1000, bbox_inches='tight')
        merger.append(all_cls_barplt_file_path)
        plt.cla()

        shap_file_name = 'compiled_shap_plot.pdf'
        shap_file_path = os.path.join(global_reports, 'shap' , shap_file_name)
        merger.write(shap_file_path)

        

class DeepExplainer(Explain):
    '''
    An implementation of Deep SHAP, a faster (but only approximate) algorithm to compute SHAP values 
    for deep learning models that is based on connections between SHAP and the DeepLIFT algorithm.
    This Explainer is be used for Deep Learning Based Algorithms
    Some of the Supported Algorithms are as below -
    TensorFlow/Keras models
    LSTM / RNN
    CNN
    PyTorch Deep Explainer
    and Deep Learning Based Algorithms
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the TreeExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(DeepExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.DeepExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a sample of data 
        or batch of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values
        print('local')
    
    def shap_glbe(self, *args, **kwargs):
        '''
        Global Plotting
        '''
        return shap.summary_plot(*args, **kwargs)

class GradientExplainer(Explain):
    '''
    An implementation of expected gradients to approximate SHAP values for deep learning models. 
    It is based on connections between SHAP and the Integrated Gradients algorithm. 
    GradientExplainer is slower than DeepExplainer and makes different approximation assumptions.
    Some of the supported algorithm are as below-
    TensorFlow/Keras/PyTorch models
    CNN
    Transfer Learning Techniques - VGG16, RESNET50 amd others
    Explain an Intermediate Layer of Transfer Learning Techniques
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the GradientExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(GradientExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.GradientExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, *args, **kwargs):
        '''
        Global Plotting
        '''
        return shap.summary_plot(*args, **kwargs)

class LinearExplainer(Explain):
    '''
    For a linear model with independent features we can analytically compute the exact SHAP values. 
    We can also account for feature correlation if we are willing to estimate the feature covaraince matrix. 
    LinearExplainer supports both of these options.
    Some of the supported algorithm are as below-
    Linear Regression
    Logistic Regression
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the LinearExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(LinearExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.LinearExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, *args, **kwargs):
        '''
        Global Plotting
        '''
        return shap.summary_plot(*args, **kwargs)

class KernelExplainer(Explain):
    '''
    An implementation of Kernel SHAP, a model agnostic method to estimate SHAP values for any model. 
    Because it makes not assumptions about the model type, 
    KernelExplainer is slower than the other model type specific algorithms.
    This Explainer is model Agnostic and can explain any algorithm.
    Some of the supported algorithm are as below-
    ANN
    LinearRegression
    Neural network like MLPRegressor, MLPClassifier
    KNeighborsClassifier
    SVC
    LogisticRegression
    DecisionTreeClassifier
    RandomForestClassifier
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the KernelExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(KernelExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.KernelExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, *args, **kwargs):
        '''
        Global Plotting
        '''
        return shap.summary_plot(*args, **kwargs)

class Explainer(Explain):
    '''
    SHAP has specific support for natural language models like those in the Hugging Face transformers library. 
    By adding coalitional rules to traditional Shapley values we can form games 
    that explain large modern NLP model using very few function evaluations.
    Best Suited for Natural Language usecases using Transformers.
    This also has Fast C++ implementation support for XGBoost, LightGBM, CatBoost, scikit-learn and pyspark tree models.
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the Explainer object
        Explainer to be fit on Trained Model Object
        '''
        super(Explainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.Explainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, *args, **kwargs):
        '''
        Global Plotting
        '''
        return shap.summary_plot(*args, **kwargs)

class SaveHTML():

    def __init__(self, *args, **kwargs):
        pass

    def shap_save_html(self, *args, **kwargs):
        return shap.save_html(*args, **kwargs)

    def shap_force_plot(self, *args, **kwargs):
        '''
        Local Plotting
        '''
        return shap.force_plot(*args, **kwargs)

# class AddModels():

#     def __init__(self):
#         pass

#     def add_model(self, exp, def_list=[]):
#         def_list.append(exp)
#         return def_list
    
#     def shap_explanation(self, explainer, data, target_class):
#         for i, value in enumerate(explainer):
#             shap_values = explainer[i].shap_localexplanation(data)
#             local_explainer = shap.force_plot(explainer[i].explainer.expected_value[target_class], 
#                                                         shap_values[target_class], data)
#             shap.save_html('reports/local/local_tree_explainer'+'model_'+str(i)+'1.html', local_explainer)

class AddModels():

    def __init__(self):
        pass

    def add_model(self, exp, name, def_list=[]):
        def_list.append([exp, name])
        return def_list
    
    def shap_explanation(self, explainer, data, target_class):
        for i, value in enumerate(explainer):
            shap_values = explainer[i][0].shap_loce(data)
            local_explainer = shap.force_plot(explainer[i][0].explainer.expected_value[target_class], 
                                                        shap_values[target_class], data)
            shap.save_html('reports/local/local_tree_explainer__'+ explainer[i][1] +'.html', local_explainer)

print('Compiled')