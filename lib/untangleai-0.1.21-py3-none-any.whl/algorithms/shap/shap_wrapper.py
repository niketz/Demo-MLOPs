import shap
import sys, os
# print(sys.path.append(os.path.join(os.path.dirname(sys.path[0]))))
# print(sys.path)
from untangleai.algorithms.shap.explainer import Explain
import matplotlib.pyplot as plt
import PyPDF2
import numpy as np
import pandas as pd
# from wrapper.explainer import Explain

class TreeExplainer(Explain):
    '''
    An implementation of Tree SHAP, a fast and exact algorithm to compute SHAP values for trees and ensembles of trees.
    This Explainer is be used for Tree Based Algorithms
    Some of the Supported Algorithms are as below -
    RandomForest
    DecisionTee
    LightGBM
    XGBoost
    CatBoost
    GradientBoostingClassifier
    and other tree based algorithm
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the TreeExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(TreeExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.TreeExplainer(*args, **kwargs)

    def shap_loce(self, mode, X_test, target_class, data_for_prediction, algorithm, row):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        # Method 1 - Saving as HTML
        # shap.save_html('reports/local/local_explainer.html', 
        #                 shap.force_plot(*args, *kwargs, show=False, matplotlib=False))
        #Method 2 - Saving as PDF
        if mode == 'classification':
            if algorithm == 'XGBoost':
                shap_values = self.explainer.shap_values(data_for_prediction)
                local_plt = shap.force_plot(self.explainer.expected_value, shap_values, data_for_prediction)
                return local_plt
            else:
                shap_values = self.explainer.shap_values(data_for_prediction)
                local_plt = shap.force_plot(self.explainer.expected_value[target_class], shap_values[target_class], data_for_prediction)
                # shap.save_html('test.html',local_plt)
                return local_plt
        else:
            if algorithm == 'XGBoost':
                shap_values = self.explainer.shap_values(data_for_prediction)
                local_plt = shap.force_plot(self.explainer.expected_value, shap_values, data_for_prediction)
                return local_plt
            else:
                shap_values = self.explainer.shap_values(data_for_prediction)
                local_plt = shap.force_plot(self.explainer.expected_value, shap_values, data_for_prediction)
                # shap.save_html('test.html',local_plt)
                return local_plt

    def shap_glbe(self, X_test, mode, algorithm, target_class=None, plot_type=None):
        '''
        Global Plotting
        '''
        shap_values = self.explainer.shap_values(X_test)
        if mode == 'classification':
            if algorithm != 'XGBoost':
                if target_class != None:
                    if plot_type == None:
                        return (shap.summary_plot(shap_values[target_class], X_test, show=False))
                    else:
                        return (shap.summary_plot(shap_values[target_class], X_test, plot_type=plot_type, show=False))
                else:
                    return (shap.summary_plot(shap_values, X_test, plot_type=plot_type, show=False))
            else:
                if plot_type == None:
                    return (shap.summary_plot(shap_values, X_test, show=False))
                else:
                    return (shap.summary_plot(shap_values, X_test, plot_type=plot_type, show=False))
        else:
            if plot_type == None:
                return (shap.summary_plot(shap_values, X_test, show=False))
            else:
                return (shap.summary_plot(shap_values, X_test, plot_type=plot_type, show=False))
    
    def shap_impfeat(self, X_test, mode, algorithm):
        shap_values = self.explainer.shap_values(X_test)
        if mode == 'classification':
            if algorithm != 'XGBoost':
                vals = np.abs(shap_values).mean(0).mean(0)
            else:
                vals = np.abs(shap_values).mean(0)
        else:
            vals = np.abs(shap_values).mean(0)
        feature_names = X_test.columns
        feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
        feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
        if len(feature_importance['col_name']) < 5:
            imp_shap_feat = feature_importance['col_name'].tolist()
        else:
            imp_shap_feat = feature_importance['col_name'][0:5].tolist()
        return imp_shap_feat
    
    def shap_corr_plot(self, X_test, mode, algorithm, target_class):
        #import matplotlib as plt
        # Make a copy of the input data
        shap_values = self.explainer.shap_values(X_test)
        if mode == 'classification':
            if algorithm == 'XGBoost':
                shap_v = pd.DataFrame(shap_values)
            else:
                shap_v = pd.DataFrame(shap_values[target_class])
        else:
            shap_v = pd.DataFrame(shap_values)
        feature_list = X_test.columns
        shap_v.columns = feature_list
        df_v = X_test.copy().reset_index().drop('index',axis=1)
        
        # Determine the correlation in order to plot with different colors
        corr_list = list()
        for i in feature_list:
            b = np.corrcoef(shap_v[i],df_v[i])[1][0]
            corr_list.append(b)
        corr_df = pd.concat([pd.Series(feature_list),pd.Series(corr_list)],axis=1).fillna(0)
        # Make a data frame. Column 1 is the feature, and Column 2 is the correlation coefficient
        corr_df.columns  = ['Variable','Corr']
        corr_df['Sign'] = np.where(corr_df['Corr']>0,'red','blue')
        
        # Plot it
        shap_abs = np.abs(shap_v)
        k=pd.DataFrame(shap_abs.mean()).reset_index()
        k.columns = ['Variable','SHAP_abs']
        k2 = k.merge(corr_df,left_on = 'Variable',right_on='Variable',how='inner')
        k2 = k2.sort_values(by='SHAP_abs',ascending = True)
        colorlist = k2['Sign']
        ax = k2.plot.barh(x='Variable',y='SHAP_abs',color = colorlist, figsize=(5,6),legend=False)
        ax.set_xlabel("SHAP Value (Red = Positive Impact)")
        return ax

class DeepExplainer(Explain):
    '''
    An implementation of Deep SHAP, a faster (but only approximate) algorithm to compute SHAP values 
    for deep learning models that is based on connections between SHAP and the DeepLIFT algorithm.
    This Explainer is be used for Deep Learning Based Algorithms
    Some of the Supported Algorithms are as below -
    TensorFlow/Keras models
    LSTM / RNN
    CNN
    PyTorch Deep Explainer
    and Deep Learning Based Algorithms
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the TreeExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(DeepExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.DeepExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a sample of data 
        or batch of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values
        print('local')
    
    def shap_glbe(self, X_test, target_class=None, plot_type=None):
        '''
        Global Plotting
        '''
        shap_values = self.explainer.shap_values(X_test)
        if target_class != None:
            if plot_type == None:
                return (shap.summary_plot(shap_values[target_class], X_test, show=False))
            else:
                return (shap.summary_plot(shap_values[target_class], X_test, plot_type=plot_type, show=False))
        else:
            return (shap.summary_plot(shap_values, X_test, plot_type=plot_type,show=False))

    def shap_impfeat(self, X_test):
        shap_values = self.explainer.shap_values(X_test)
        vals = np.abs(shap_values).mean(0).mean(0)
        feature_names = X_test.columns
        feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
        feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
        if len(feature_importance['col_name']) < 5:
            imp_shap_feat = feature_importance['col_name'].tolist()
        else:
            imp_shap_feat = feature_importance['col_name'][0:5].tolist()
        return imp_shap_feat

class GradientExplainer(Explain):
    '''
    An implementation of expected gradients to approximate SHAP values for deep learning models. 
    It is based on connections between SHAP and the Integrated Gradients algorithm. 
    GradientExplainer is slower than DeepExplainer and makes different approximation assumptions.
    Some of the supported algorithm are as below-
    TensorFlow/Keras/PyTorch models
    CNN
    Transfer Learning Techniques - VGG16, RESNET50 amd others
    Explain an Intermediate Layer of Transfer Learning Techniques
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the GradientExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(GradientExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.GradientExplainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, X_test, target_class=None, plot_type=None):
        '''
        Global Plotting
        '''
        shap_values = self.explainer.shap_values(X_test)
        if target_class != None:
            if plot_type == None:
                return (shap.summary_plot(shap_values[target_class], X_test, show=False))
            else:
                return (shap.summary_plot(shap_values[target_class], X_test, plot_type=plot_type, show=False))
        else:
            return (shap.summary_plot(shap_values, X_test, plot_type=plot_type,show=False))

    def shap_impfeat(self, X_test):
        shap_values = self.explainer.shap_values(X_test)
        vals = np.abs(shap_values).mean(0).mean(0)
        feature_names = X_test.columns
        feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
        feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
        if len(feature_importance['col_name']) < 5:
            imp_shap_feat = feature_importance['col_name'].tolist()
        else:
            imp_shap_feat = feature_importance['col_name'][0:5].tolist()
        return imp_shap_feat

class LinearExplainer(Explain):
    '''
    For a linear model with independent features we can analytically compute the exact SHAP values. 
    We can also account for feature correlation if we are willing to estimate the feature covaraince matrix. 
    LinearExplainer supports both of these options.
    Some of the supported algorithm are as below-
    Linear Regression
    Logistic Regression
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the LinearExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(LinearExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.LinearExplainer(*args, **kwargs)

    def shap_loce(self, mode, X_test, target_class, data_for_prediction, algorithm, row):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        # Method 1 - Saving as HTML
        # shap.save_html('reports/local/local_explainer.html', 
        #                 shap.force_plot(*args, *kwargs, show=False, matplotlib=False))
        #Method 2 - Saving as PDF
        if mode == 'classification':
            shap_values = self.explainer.shap_values(data_for_prediction)
            local_plt = shap.force_plot(self.explainer.expected_value, shap_values, data_for_prediction)
            # shap.save_html('test.html',local_plt)
            return local_plt
        else:
            shap_values = self.explainer.shap_values(data_for_prediction)
            local_plt = shap.force_plot(self.explainer.expected_value, shap_values, data_for_prediction)
            # shap.save_html('test.html',local_plt)
            return local_plt

    def shap_glbe(self, X_test, mode, algorithm, target_class=None, plot_type=None):
        '''
        Global Plotting
        '''
        shap_values = self.explainer.shap_values(X_test)
        if target_class != None:
            if plot_type == None:
                return (shap.summary_plot(shap_values, X_test, show=False))
            else:
                return (shap.summary_plot(shap_values, X_test, plot_type=plot_type, show=False))
        else:
            return (shap.summary_plot(shap_values, X_test, plot_type=plot_type,show=False))
    
    def shap_impfeat(self, X_test, mode, algorithm):
        shap_values = self.explainer.shap_values(X_test)
        vals = np.abs(shap_values).mean(0)
        feature_names = X_test.columns
        feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
        feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
        if len(feature_importance['col_name']) < 5:
            imp_shap_feat = feature_importance['col_name'].tolist()
        else:
            imp_shap_feat = feature_importance['col_name'][0:5].tolist()
        return imp_shap_feat

    def shap_corr_plot(self, X_test, mode, algorithm, target_class):
        #import matplotlib as plt
        # Make a copy of the input data
        shap_values = self.explainer.shap_values(X_test)
        shap_v = pd.DataFrame(shap_values)
        feature_list = X_test.columns
        shap_v.columns = feature_list
        df_v = X_test.copy().reset_index().drop('index',axis=1)
        
        # Determine the correlation in order to plot with different colors
        corr_list = list()
        for i in feature_list:
            b = np.corrcoef(shap_v[i],df_v[i])[1][0]
            corr_list.append(b)
        corr_df = pd.concat([pd.Series(feature_list),pd.Series(corr_list)],axis=1).fillna(0)
        # Make a data frame. Column 1 is the feature, and Column 2 is the correlation coefficient
        corr_df.columns  = ['Variable','Corr']
        corr_df['Sign'] = np.where(corr_df['Corr']>0,'red','blue')
        
        # Plot it
        shap_abs = np.abs(shap_v)
        k=pd.DataFrame(shap_abs.mean()).reset_index()
        k.columns = ['Variable','SHAP_abs']
        k2 = k.merge(corr_df,left_on = 'Variable',right_on='Variable',how='inner')
        k2 = k2.sort_values(by='SHAP_abs',ascending = True)
        colorlist = k2['Sign']
        ax = k2.plot.barh(x='Variable',y='SHAP_abs',color = colorlist, figsize=(5,6),legend=False)
        ax.set_xlabel("SHAP Value (Red = Positive Impact)")
        return ax

class KernelExplainer(Explain):
    '''
    An implementation of Kernel SHAP, a model agnostic method to estimate SHAP values for any model. 
    Because it makes not assumptions about the model type, 
    KernelExplainer is slower than the other model type specific algorithms.
    This Explainer is model Agnostic and can explain any algorithm.
    Some of the supported algorithm are as below-
    ANN
    LinearRegression
    Neural network like MLPRegressor, MLPClassifier
    KNeighborsClassifier
    SVC
    LogisticRegression
    DecisionTreeClassifier
    RandomForestClassifier
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the KernelExplainer object
        Explainer to be fit on Trained Model Object
        '''
        super(KernelExplainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.KernelExplainer(*args, **kwargs)

    def shap_loce(self, mode, X_test, target_class, data_for_prediction, algorithm, row):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        # Method 1 - Saving as HTML
        # shap.save_html('reports/local/local_explainer.html', 
        #                 shap.force_plot(*args, *kwargs, show=False, matplotlib=False))
        #Method 2 - Saving as PDF
        if mode == 'classification':
            shap_values = self.explainer.shap_values(X_test, nsamples=100)
            # local_plt = shap.force_plot(self.explainer.expected_value, shap_values, data_for_prediction)
            local_plt = shap.force_plot(self.explainer.expected_value[target_class], shap_values[target_class][row,:], X_test.iloc[row,:])
            # shap.save_html('test.html',local_plt)
            return local_plt
        else:
            shap_values = self.explainer.shap_values(X_test, nsamples=100)
            local_plt = shap.force_plot(self.explainer.expected_value, shap_values[row,:], X_test.iloc[row,:])
            # shap.save_html('test.html',local_plt)
            return local_plt

    def shap_glbe(self, X_test, mode, algorithm, target_class=None, plot_type=None):
        '''
        Global Plotting
        '''
        shap_values = self.explainer.shap_values(X_test, nsamples=100)
        if mode == 'classification':
            if target_class != None:
                if plot_type == None:
                    return (shap.summary_plot(shap_values[target_class], X_test, show=False))
                else:
                    return (shap.summary_plot(shap_values[target_class], X_test, plot_type=plot_type, show=False))
            else:
                return (shap.summary_plot(shap_values, X_test, plot_type=plot_type,show=False))
        else:
            if plot_type == None:
                return (shap.summary_plot(shap_values, X_test, show=False))
            else:
                return (shap.summary_plot(shap_values, X_test, plot_type=plot_type, show=False))

    def shap_impfeat(self, X_test, mode, algorithm):
        shap_values = self.explainer.shap_values(X_test)
        if mode == 'classification':
            vals = np.abs(shap_values).mean(0).mean(0)
        else:
            vals = np.abs(shap_values).mean(0)
        feature_names = X_test.columns
        feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
        feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
        if len(feature_importance['col_name']) < 5:
            imp_shap_feat = feature_importance['col_name'].tolist()
        else:
            imp_shap_feat = feature_importance['col_name'][0:5].tolist()
        return imp_shap_feat
    
    def shap_corr_plot(self, X_test, mode, algorithm, target_class):
        #import matplotlib as plt
        # Make a copy of the input data
        shap_values = self.explainer.shap_values(X_test)
        if mode == 'classification':
            shap_v = pd.DataFrame(shap_values[target_class])
        else:
            shap_v = pd.DataFrame(shap_values)
        feature_list = X_test.columns
        shap_v.columns = feature_list
        df_v = X_test.copy().reset_index().drop('index',axis=1)
        
        # Determine the correlation in order to plot with different colors
        corr_list = list()
        for i in feature_list:
            b = np.corrcoef(shap_v[i],df_v[i])[1][0]
            corr_list.append(b)
        corr_df = pd.concat([pd.Series(feature_list),pd.Series(corr_list)],axis=1).fillna(0)
        # Make a data frame. Column 1 is the feature, and Column 2 is the correlation coefficient
        corr_df.columns  = ['Variable','Corr']
        corr_df['Sign'] = np.where(corr_df['Corr']>0,'red','blue')
        
        # Plot it
        shap_abs = np.abs(shap_v)
        k=pd.DataFrame(shap_abs.mean()).reset_index()
        k.columns = ['Variable','SHAP_abs']
        k2 = k.merge(corr_df,left_on = 'Variable',right_on='Variable',how='inner')
        k2 = k2.sort_values(by='SHAP_abs',ascending = True)
        colorlist = k2['Sign']
        ax = k2.plot.barh(x='Variable',y='SHAP_abs',color = colorlist, figsize=(5,6),legend=False)
        ax.set_xlabel("SHAP Value (Red = Positive Impact)")
        return ax

class Explainer(Explain):
    '''
    SHAP has specific support for natural language models like those in the Hugging Face transformers library. 
    By adding coalitional rules to traditional Shapley values we can form games 
    that explain large modern NLP model using very few function evaluations.
    Best Suited for Natural Language usecases using Transformers.
    This also has Fast C++ implementation support for XGBoost, LightGBM, CatBoost, scikit-learn and pyspark tree models.
    '''

    def __init__(self, *args, **kwargs):
        ''' 
        Initializing the Explainer object
        Explainer to be fit on Trained Model Object
        '''
        super(Explainer, self).__init__(*args, **kwargs)

        shap.initjs()

        self.explainer = shap.Explainer(*args, **kwargs)

    def shap_loce(self, *args, **kwargs):
        '''
        Local Explanation can be viewed for a row of data 
        or batch of row of data
        '''
        shap_values = self.explainer.shap_values(*args, **kwargs)
        return shap_values

    def shap_glbe(self, X_test, target_class=None, plot_type=None):
        '''
        Global Plotting
        '''
        shap_values = self.explainer.shap_values(X_test)
        if target_class != None:
            if plot_type == None:
                return (shap.summary_plot(shap_values[target_class], X_test, show=False))
            else:
                return (shap.summary_plot(shap_values[target_class], X_test, plot_type=plot_type, show=False))
        else:
            return (shap.summary_plot(shap_values, X_test, plot_type=plot_type,show=False))

    def shap_impfeat(self, X_test):
        shap_values = self.explainer.shap_values(X_test)
        vals = np.abs(shap_values).mean(0).mean(0)
        feature_names = X_test.columns
        feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
        feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
        if len(feature_importance['col_name']) < 5:
            imp_shap_feat = feature_importance['col_name'].tolist()
        else:
            imp_shap_feat = feature_importance['col_name'][0:5].tolist()
        return imp_shap_feat

class SaveHTML():

    def __init__(self, *args, **kwargs):
        pass

    def shap_save_html(self, *args, **kwargs):
        return shap.save_html(*args, **kwargs)

    def shap_force_plot(self, *args, **kwargs):
        '''
        Local Plotting
        '''
        return shap.force_plot(*args, **kwargs)
    
    def shap_summary_plot(self, *args, **kwargs):
        '''
        Global Plotting
        '''
        return shap.summary_plot(*args, **kwargs)

# class AddModels():

#     def __init__(self):
#         pass

#     def add_model(self, exp, def_list=[]):
#         def_list.append(exp)
#         return def_list
    
#     def shap_explanation(self, explainer, data, target_class):
#         for i, value in enumerate(explainer):
#             shap_values = explainer[i].shap_localexplanation(data)
#             local_explainer = shap.force_plot(explainer[i].explainer.expected_value[target_class], 
#                                                         shap_values[target_class], data)
#             shap.save_html('reports/local/local_tree_explainer'+'model_'+str(i)+'1.html', local_explainer)

class AddModels():

    def __init__(self):
        pass

    def add_model(self, exp, name, def_list=[]):
        def_list.append([exp, name])
        return def_list
    
    def shap_explanation(self, explainer, data, target_class):
        for i, value in enumerate(explainer):
            shap_values = explainer[i][0].shap_loce(data)
            local_explainer = shap.force_plot(explainer[i][0].explainer.expected_value[target_class], 
                                                        shap_values[target_class], data)
            shap.save_html('reports/local/local_tree_explainer__'+ explainer[i][1] +'.html', local_explainer)

print('Compiled')