import matplotlib
import yaml
import argparse
import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import time
timestr = time.strftime("%Y%m%d-%H%M%S")

from untangleai.algorithms.shap.shap_wrapper import TreeExplainer, DeepExplainer, GradientExplainer, LinearExplainer, KernelExplainer, Explainer, SaveHTML, AddModels
from untangleai.algorithms.shap.get_data import get_data
# from untangleai.algorithms.shap.plot_graph import glbe_target_class_plot, local_explainer_one_data_plot, glbe_all_class, local_explainer_complete_data_plot
from untangleai.algorithms.shap.plot_graph import shap_glbe_plot, shap_loce_plot

def process_data(config_path):
    model, mode, algorithm, X, X_train, X_test, row_index_to_explain, target_class, local_reports, global_reports, rowid = get_data(config_path)
    
    # Loading necessary files for generating explanations
    model = pickle.load(open(model,'rb'))
    # algorithm = model.__class__.__name__
    # print(algorithm)

    X = pd.read_csv(X)
    X_train = pd.read_csv(X_train)
    X_test = pd.read_csv(X_test)

    if algorithm in ['RandomForest','DecisionTee','LightGBM','XGBoost','CatBoost','GradientBoostingClassifier','OtherTreeAlgorithm']:

        # Initializing Explainer Object
        explainer = TreeExplainer(model)
        # print(mode,'inside process data file')

        shapplt_list, imp_shap_feat = shap_glbe_plot(explainer, X_test, target_class, global_reports, algorithm, mode)
        shaploc_plt_list = shap_loce_plot(explainer, X_test, target_class, local_reports, algorithm, mode, rowid)
        # print(shaploc_plt_list, type(shaploc_plt_list), '^^^^^^^^^^^^')
        # explainer.shap_glbe(X_test, target_class, global_reports, algorithm)

        # # Generating Global Explanations for Target Class
        # glbe_target_class_plot(explainer, X_test, target_class, global_reports, algorithm)
        # plt.cla()

        # # Generating Global Explanations for All Classes
        # glbe_all_class(explainer, X_train, global_reports, algorithm)
        # plt.cla()

        # # Generating Local Explanations for one datapoint
        # local_explainer_one_data_plot(explainer, X_test, row_index_to_explain, target_class, local_reports, algorithm)
        # plt.cla()

        # # Generating Local Explanations for Entire Dataset
        # local_explainer_complete_data_plot(explainer, X_test, target_class, local_reports, algorithm)
        # plt.cla()
        return shapplt_list, imp_shap_feat, shaploc_plt_list

    elif algorithm in ['ANN','CNN','LSTM','RNN','Pytorch']:
        # Initializing Explainer Object
        explainer = DeepExplainer(model)
        pass
    
    elif algorithm in ['ANN','CNN','Pytorch']:
        # Initializing Explainer Object
        explainer = GradientExplainer(model)
        pass

    # elif algorithm in ['LinearRegression','LogisticRegression']:
    elif algorithm in ['LinearRegression','LogisticRegression']:
        # Initializing Explainer Object
        print('Inside Linear Shap')
        explainer = LinearExplainer(model, X_train)
        shapplt_list, imp_shap_feat = shap_glbe_plot(explainer, X_test, target_class, global_reports, algorithm, mode)
        shaploc_plt_list = shap_loce_plot(explainer, X_test, target_class, local_reports, algorithm, mode, rowid)
        return shapplt_list, imp_shap_feat, shaploc_plt_list        

    # elif algorithm in ['KNN','ANN','LinearRegression','LogisticRegression','MLP','SVM','DecisionTree','RandomForest','ModelAgnostic']:
    elif algorithm in ['KNN','ANN','MLP','SVM','ModelAgnostic']:
        # Initializing Explainer Object
        print('I am here in Kernel Explainer')
        if mode == 'classification':
            explainer = KernelExplainer(model.predict_proba, X_train)
        else:
            explainer = KernelExplainer(model.predict, X_test)
        shapplt_list, imp_shap_feat = shap_glbe_plot(explainer, X_test, target_class, global_reports, algorithm, mode)
        shaploc_plt_list = shap_loce_plot(explainer, X_test, target_class, local_reports, algorithm, mode, rowid)
        return shapplt_list, imp_shap_feat, shaploc_plt_list

    elif algorithm in ['Transformers']:
        # Initializing Explainer Object
        explainer = Explainer(model)
        pass

    else:
        print('I am in fall back explainer')
        if mode == 'classification':
            explainer = KernelExplainer(model.predict_proba, X_train)
        else:
            explainer = KernelExplainer(model.predict, X_test)
        shapplt_list, imp_shap_feat = shap_glbe_plot(explainer, X_test, target_class, global_reports, algorithm, mode)
        shaploc_plt_list = shap_loce_plot(explainer, X_test, target_class, local_reports, algorithm, mode, rowid)
        return shapplt_list, imp_shap_feat, shaploc_plt_list




# if __name__ == "__main__":
#     args = argparse.ArgumentParser()
#     args.add_argument("--config", default="params.yaml")
#     parsed_args = args.parse_args()

#     preprocess_data(config_path=parsed_args.config)
