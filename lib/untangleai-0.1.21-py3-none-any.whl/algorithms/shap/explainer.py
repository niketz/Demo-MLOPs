import abc
import sys

if sys.version_info >= (3, 4):
    ABC = abc.ABC
else:
    ABC = abc.ABCMeta(str('ABC'), (), {})

class Explain(ABC):

    def __init__(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def shap_loce(self, *args, **kwargs):
        raise NoImplementationError
    
    @abc.abstractmethod
    def shap_glbe(self, *args, **kwargs):
        raise NoImplementationError
