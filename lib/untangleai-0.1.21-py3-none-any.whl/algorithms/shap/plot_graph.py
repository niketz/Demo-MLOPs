import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import PyPDF2
import time
import os
timestr = time.strftime("%Y%m%d-%H%M%S")

from untangleai.algorithms.shap.shap_wrapper import TreeExplainer, DeepExplainer, GradientExplainer, LinearExplainer, KernelExplainer, Explainer, SaveHTML, AddModels
from untangleai.algorithms.shap.get_data import read_params, get_data

plotter = SaveHTML()

def shap_glbe_plot(explainer, X_test, target_class, global_reports, algorithm, mode):
    
    merger = PyPDF2.PdfFileMerger()

    shap_path = os.path.join(global_reports ,'shap', 'shap_temp')
    try:
        os.makedirs(shap_path)
    except OSError as error: 
        pass
    
    shapplt_list = []
    # tgt_cls_file_name = 'explainer_tgt_cls_' + algorithm + '.png'
    tgt_cls_file_name = 'summary_plot' + '.png'
    tgt_cls_file_path = os.path.join(shap_path, tgt_cls_file_name)
    if mode == 'classification':
        explainer.shap_glbe(X_test, mode, algorithm, target_class)
    else:
        explainer.shap_glbe(X_test, mode, algorithm)
    plt.savefig(tgt_cls_file_path, format='png', dpi=100, bbox_inches='tight')
    # merger.append(tgt_cls_file_path)
    shapplt_list.append(os.path.join('global','shap','shap_temp',tgt_cls_file_name))
    plt.close("all")
    
    # tgt_cls_barplt_file_name = 'explainer_bar_plt_tgt_cls_' + algorithm + '.png'
    tgt_cls_barplt_file_name = 'feature_importance' + '.png'
    tgt_cls_barplt_file_path = os.path.join(shap_path, tgt_cls_barplt_file_name)
    if mode == 'classification':
        explainer.shap_glbe(X_test, mode, algorithm, target_class, plot_type='bar')
    else:
        explainer.shap_glbe(X_test, mode, algorithm, plot_type='bar')
    plt.savefig(tgt_cls_barplt_file_path, format='png', dpi=100, bbox_inches='tight')
    # merger.append(tgt_cls_barplt_file_path)
    shapplt_list.append(os.path.join('global','shap','shap_temp',tgt_cls_barplt_file_name))
    plt.close("all")

    all_cls_barplt_file_name = 'explainer_bar_all_cls_' + '.png'
    all_cls_barplt_file_path = os.path.join(shap_path, all_cls_barplt_file_name)
    explainer.shap_glbe(X_test, mode, algorithm, plot_type='bar')
    plt.savefig(all_cls_barplt_file_path, format='png', dpi=100, bbox_inches='tight')
    # merger.append(all_cls_barplt_file_path)
    shapplt_list.append(os.path.join('global','shap','shap_temp',all_cls_barplt_file_name))
    plt.close("all")

    corr_feat_imp_file_name = 'correlation_feature_importance' + '.png'
    corr_feat_imp_file_path = os.path.join(shap_path, corr_feat_imp_file_name)
    explainer.shap_corr_plot(X_test, mode, algorithm, target_class)
    # explainer.shap_glbe(X_test, mode, algorithm, plot_type='bar')
    plt.savefig(corr_feat_imp_file_path, format='png', dpi=100, bbox_inches='tight')
    # merger.append(corr_summary_plot_file_path)
    shapplt_list.append(os.path.join('global','shap','shap_temp',corr_feat_imp_file_name))
    plt.close("all")

    imp_shap_feat = explainer.shap_impfeat(X_test, mode, algorithm)
    # shap_values = explainer.shap_val(X_test)
    # vals = np.abs(shap_values).mean(0).mean(0)
    # feature_names = X_test.columns
    # feature_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name','feature_importance_vals'])
    # feature_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
    # if len(feature_importance['col_name']) < 5:
    #     imp_shap_feat = feature_importance['col_name'].tolist()
    # else:
    #     imp_shap_feat = feature_importance['col_name'][0:5].tolist()

    # shap_file_name = 'compiled_shap_plot.pdf'
    # shap_file_path = os.path.join(global_reports, 'shap' , shap_file_name)
    # merger.write(shap_file_path)
    # plt.cla()
    
    return shapplt_list, imp_shap_feat

def shap_loce_plot(explainer, X_test, target_class, local_reports, algorithm, mode, rowid):

    shap_path = os.path.join(local_reports ,'shap', 'shap_temp')
    try:
        os.makedirs(shap_path)
    except OSError as error: 
        pass

    shaploc_plt_list = []


    for row in rowid:
        if algorithm in ['LightGBM','XGBoost']:
            data_for_prediction = X_test.iloc[row].values.reshape(1, -1)
        else:
            data_for_prediction = X_test.iloc[row]
        local_plt = explainer.shap_loce(mode, X_test, target_class, data_for_prediction, algorithm, row)
        filename = 'shap_loce_'+str(row)+'_.html'
        filepath = os.path.join(shap_path, filename)
        plotter.shap_save_html(filepath, local_plt)
        shaploc_plt_list.append((os.path.join('local','shap','shap_temp',filename), row))
    
    
    return shaploc_plt_list
