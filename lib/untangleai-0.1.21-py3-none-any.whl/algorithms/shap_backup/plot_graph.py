import matplotlib.pyplot as plt

import time
timestr = time.strftime("%Y%m%d-%H%M%S")

from untangleai.algorithms.shap.shap_wrapper import TreeExplainer, DeepExplainer, GradientExplainer, LinearExplainer, KernelExplainer, Explainer, SaveHTML, AddModels
from untangleai.algorithms.shap.get_data import read_params, get_data

plotter = SaveHTML()

# Generating Global Explanations for Target Class
def global_explainer_target_class_plot(explainer, X_train, target_class, global_reports, algorithm):
    shap_values = explainer.shap_localexplanation(X_train)
    global_explainer_target_class = explainer.shap_globalexplanation(shap_values[target_class], X_train, show=False)
    plt.savefig((global_reports + '/global_tree_explainer_target_class_' + algorithm + '.pdf'), format='pdf', dpi=1000, bbox_inches='tight')
    plt.cla()

# Generating Global Explanations for All Classes
def global_explainer_all_class(explainer, X_train, global_reports, algorithm):
    shap_values = explainer.shap_localexplanation(X_train)
    global_explainer_all_class = explainer.shap_globalexplanation(shap_values, X_train, show=False)
    plt.savefig((global_reports + '/global_tree_explainer_all_class' + algorithm + '.pdf'), format='pdf', dpi=1000, bbox_inches='tight')
    plt.cla()

# Generating Local Explanations for one datapoint
def local_explainer_one_data_plot(explainer, X_test, row_index_to_explain, target_class, local_reports, algorithm):
    shap_values = explainer.shap_localexplanation(X_test.iloc[row_index_to_explain,:])
    local_explainer_one_data = plotter.shap_force_plot(explainer.explainer.expected_value[target_class], shap_values[target_class], X_test.iloc[row_index_to_explain,:])
    plotter.shap_save_html(local_reports + '/local_tree_explainer_one_data'+ algorithm + '.html', local_explainer_one_data)
    local_explainer_one_data = plotter.shap_force_plot(explainer.explainer.expected_value[target_class], shap_values[target_class], X_test.iloc[row_index_to_explain,:], show=False, matplotlib=True)
    plt.savefig((local_reports + '/local_tree_explainer_'+ algorithm + '.pdf'), format='pdf', dpi=1000, bbox_inches='tight')
    plt.cla()

# Generating Local Explanations for Entire Dataset
def local_explainer_complete_data_plot(explainer, X_test, target_class, local_reports, algorithm):
    shap_values = explainer.shap_localexplanation(X_test)
    local_explainer_complete_data = plotter.shap_force_plot(explainer.explainer.expected_value[target_class], shap_values[target_class], X_test)
    plotter.shap_save_html(local_reports + '/local_tree_explainer_complete_data_'+ algorithm + '.html', local_explainer_complete_data)
    # Exception: matplotlib = True is not yet supported for force plots with multiple samples!
    # local_explainer_complete_data = plotter.shap_force_plot(explainer.explainer.expected_value[target_class], shap_values[target_class], X_test, show=False, matplotlib=True)
    # plt.savefig((local_reports + '/local_tree_explainer_'+ algorithm + '.pdf'), format='pdf', dpi=1000, bbox_inches='tight')
    plt.cla()