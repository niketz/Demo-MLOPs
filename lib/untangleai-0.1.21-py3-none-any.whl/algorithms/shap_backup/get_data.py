import yaml
import argparse

# config_path = "params.yaml"

def read_params(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
        return config


def get_data(config_path):
    config = read_params(config_path)
    model = config["estimators"]["models"]
    algorithm = config["estimators"]["algorithm"]
    X = config["data_source"]["X"]
    X_train = config["data_source"]["X_train"]
    X_test = config["data_source"]["X_test"]
    row_index_to_explain = config["row_index_to_explain"]
    target_class = config["target_class"]
    local_reports = config["reports"]["local"]
    global_reports = config["reports"]["global"]
    return(model, algorithm, X, X_train, X_test, row_index_to_explain, target_class, local_reports, global_reports)

# get_data(config_path)

# if __name__ == "__main__":
#     args = argparse.ArgumentParser()
#     args.add_argument("--config", default="params.yaml")
#     parsed_args = args.parse_args()
    
#     model, algorithm, X, X_train, X_test, row_index_to_explain, target_class, local_reports, global_reports = get_data(config_path=parsed_args.config)