import abc
import sys

if sys.version_info >= (3, 4):
    ABC = abc.ABC
else:
    ABC = abc.ABCMeta(str('ABC'), (), {})

class Explain(ABC):

    def __init__(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def shap_localexplanation(self, *args, **kwargs):
        raise NoImplementationError
    
    @abc.abstractmethod
    def shap_globalexplanation(self, *args, **kwargs):
        raise NoImplementationError
