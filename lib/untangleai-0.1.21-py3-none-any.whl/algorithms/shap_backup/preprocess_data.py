import matplotlib
import yaml
import argparse
import pickle
import pandas as pd
import matplotlib.pyplot as plt

import time
timestr = time.strftime("%Y%m%d-%H%M%S")

from untangleai.algorithms.shap.shap_wrapper import TreeExplainer, DeepExplainer, GradientExplainer, LinearExplainer, KernelExplainer, Explainer, SaveHTML, AddModels
from untangleai.algorithms.shap.get_data import read_params, get_data
from untangleai.algorithms.shap.plot_graph import global_explainer_target_class_plot, local_explainer_one_data_plot, global_explainer_all_class, local_explainer_complete_data_plot

def preprocess_data(config_path):
    model, algorithm, X, X_train, X_test, row_index_to_explain, target_class, local_reports, global_reports = get_data(config_path)
    
    # Loading necessary files for generating explanations
    model = pickle.load(open(model,'rb'))
    X = pd.read_csv(X)
    X_train = pd.read_csv(X_train)
    X_test = pd.read_csv(X_test)

    if algorithm in ['RandomForest','DecisionTee','LightGBM','XGBoost','CatBoost','GradientBoostingClassifier','OtherTreeAlgorithm']:

        # Initializing Explainer Object
        explainer = TreeExplainer(model)

        # Generating Global Explanations for Target Class
        global_explainer_target_class_plot(explainer, X_train, target_class, global_reports, algorithm)
        plt.cla()

        # Generating Global Explanations for All Classes
        global_explainer_all_class(explainer, X_train, global_reports, algorithm)
        plt.cla()

        # Generating Local Explanations for one datapoint
        local_explainer_one_data_plot(explainer, X_test, row_index_to_explain, target_class, local_reports, algorithm)
        plt.cla()

        # Generating Local Explanations for Entire Dataset
        local_explainer_complete_data_plot(explainer, X_test, target_class, local_reports, algorithm)
        plt.cla()

    if algorithm == ['ANN','CNN','LSTM','RNN','Pytorch']:
        # Initializing Explainer Object
        explainer = DeepExplainer(model)
        pass
    
    if algorithm == ['ANN','CNN','Pytorch']:
        # Initializing Explainer Object
        explainer = GradientExplainer(model)
        pass

    if algorithm == ['LinearRegression','LogisticRegression']:
        # Initializing Explainer Object
        explainer = LinearExplainer(model)
        pass        

    if algorithm == ['KNN','ANN','LinearRegression','LogisticRegression','MLP','SVM','DecisionTree','RandomForest','ModelAgnostic']:
        # Initializing Explainer Object
        explainer = KernelExplainer(model)
        pass

    if algorithm == ['Transformers']:
        # Initializing Explainer Object
        explainer = Explainer(model)
        pass




# if __name__ == "__main__":
#     args = argparse.ArgumentParser()
#     args.add_argument("--config", default="params.yaml")
#     parsed_args = args.parse_args()

#     preprocess_data(config_path=parsed_args.config)
