from untangleai.algorithms.eda.get_data import get_data
import pandas as pd
import numpy as np

def process_data(config_path):
    X, y, X_train, X_test, algorithm, mode, class_names = get_data(config_path)

    df = pd.read_csv(X)
    df_y = pd.read_csv(y)
    df_train = pd.read_csv(X_train)
    df_test = pd.read_csv(X_test)

    num_var = len(df.columns)
    num_obs = df.shape[0]
    train_obs = df_train.shape[0]
    test_obs = df_test.shape[0]
    model_name = algorithm
    operation_type = mode
    tgt_name = ", ".join(df_y.columns.tolist())
    features = df.columns.tolist()
    features = ", ".join(features)
    class_names = ", ".join(class_names)

    return num_var, num_obs, train_obs, test_obs, model_name, operation_type, tgt_name, features, class_names