import yaml

# config_path = "params.yaml"

def read_params(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
        return config


def get_data(config_path):
    config = read_params(config_path)
    X = config["data_source"]["X"]
    y = config["data_source"]["y"]
    X_train = config["data_source"]["X_train"]
    X_test = config["data_source"]["X_test"]
    algorithm = config["estimators"]["algorithm"]
    mode = config["estimators"]["mode"]
    class_names = config["estimators"]["class_names"]
    return(X, y, X_train, X_test, algorithm, mode, class_names)
