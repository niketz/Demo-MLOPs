from untangleai.algorithms.pdpbox.pdp_wrapper import PDP
from untangleai.algorithms.pdpbox.get_data import get_data
import pandas as pd
import pickle

def process_data(config_path):
    model, X_test, y_test, mode, global_reports, target_name = get_data(config_path)
    model = pickle.load(open(model,'rb'))
    dataset = pd.read_csv(X_test)
    dataset_y = pd.read_csv(y_test)
    target_var = ", ".join(dataset_y.columns.tolist())
    # print(target_var)

    pdp_plot = PDP()
    pdpplt_list = pdp_plot.pdp_glbe(model, dataset, mode, target_var, global_reports, target_name)
    return pdpplt_list