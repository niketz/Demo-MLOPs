import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pdpbox import pdp
from untangleai.algorithms.pdpbox.explainer import PDPExplain 
import PyPDF2
import os
import shutil
import jinja2
import kneed


class PDP(PDPExplain):
    
    def __init__(self, *args, **kwargs):
        pass

    @staticmethod
    def pdp_glbe(model, dataset, global_reports, target_name):
        pdpplt_list = []
        feature_names = dataset.columns
        merger = PyPDF2.PdfFileMerger()
        pdp_path = os.path.join(global_reports ,'pdp')
        temp_path = os.path.join(pdp_path, 'pdp_temp')
        try:
            os.mkdir(pdp_path) 
            os.mkdir(temp_path) 
        except OSError as error: 
            pass
        for each in feature_names:
            pdp_data = pdp.pdp_isolate(model=model, dataset=dataset, model_features=feature_names, feature=each, num_grid_points=5)
            pdp.pdp_plot(pdp_data, each, figsize=(9,7), center=False)
            file_name = each + '.png'
            plot_name = os.path.join(temp_path, file_name)
            try:
                i_kneedle = kneed.KneeLocator(x=pdp_data.feature_grids, y=pdp_data.pdp)
                i_knee_point = i_kneedle.knee
                if i_knee_point == pdp_data.feature_grids[0]:
                    i_knee_point = "Not Available"
                d_kneedle = kneed.KneeLocator(x=pdp_data.feature_grids, y=pdp_data.pdp, direction='decreasing')
                d_knee_point = d_kneedle.knee
                if d_knee_point == pdp_data.feature_grids[-1]:
                    d_knee_point = "Not Available"
                if i_knee_point in ["Not Available",None] and d_knee_point in ["Not Available",None]:
                    txt = "No Change in feature values"
                elif i_knee_point in ["Not Available",None] and d_knee_point not in ["Not Available",None]:
                    txt = '''Chances of {target_name}
decreases after: {d_knee_point}'''.format(target_name=target_name, d_knee_point=d_knee_point)
                elif i_knee_point not in ["Not Available",None] and d_knee_point in ["Not Available",None]:
                    txt = '''Chances of {target_name} 
increases till: {i_knee_point}'''.format(target_name=target_name, i_knee_point=i_knee_point)
                else:
#                     txt = '''Chances of getting Positive Class(Classification)/
# Higher Value(Regression) increases till: {i_knee_point} and 
# Chances of getting Positive Class(Classification)/
# Higher Value(Regression) decreases after: {d_knee_point}'''.format(i_knee_point=i_knee_point, d_knee_point=d_knee_point)
                    txt = '''Chances of {target_name}
increases till: {i_knee_point}: '''.format(target_name=target_name, i_knee_point=i_knee_point)
                # plt.figtext(0.5, 0.01, txt, wrap=True, horizontalalignment='center', fontsize=20)
                plt.figtext(0.1, 0.00, txt, wrap=True, horizontalalignment='center', fontsize=20, va="top", ha="left")
                plt.savefig(plot_name, format='png', dpi=100, bbox_inches='tight')
                plt.close("all")
            except:
                txt = "Not Enough Values to find impact"
                # plt.figtext(0.5, 0.01, txt, wrap=True, horizontalalignment='center', fontsize=20)
                plt.figtext(0.1, 0.00, txt, wrap=True, horizontalalignment='center', fontsize=20, va="top", ha="left")
                plt.savefig(plot_name, format='png', dpi=100, bbox_inches='tight')
                plt.close("all")
            pdpplt_list.append(os.path.join('global','pdp','pdp_temp',file_name))
            # merger.append(plot_name)
        # pdp_file_name = 'compiled_pdp_plot.pdf'
        # pdp_file_path = os.path.join(pdp_path, pdp_file_name)
        # merger.write(pdp_file_path)
        # shutil.rmtree(temp_path, ignore_errors = False)

        # template_path = os.path.join(os.getcwd(),'untangleai')
        # env = jinja2.Environment(loader=jinja2.FileSystemLoader(searchpath=template_path))
        # template = env.get_template('template.html')

        # html = template.render(pdp_explain='PDP Explanations')

        # report_path = os.path.join(os.getcwd(),'reports','reports.html')
        # with open(report_path, 'a') as f:
        #     print('YAYYYYYYYYYYY')
        #     f.write(html)
        return pdpplt_list

    
    def pdp_loce(self):
        pass
        