import abc
import sys

if sys.version_info >= (3, 4):
    ABC = abc.ABC
else:
    ABC = abc.ABCMeta(str('ABC'), (), {})

class PDPExplain(ABC):

    def __init__(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def pdp_glbe(self, *args, **kwargs):
        raise NoImplementationError

