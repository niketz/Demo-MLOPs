from untangleai.algorithms.lime.process_data import process_data

def run_lime_explanation(config_path="params.yaml"):
    limeplt_list = process_data(config_path)
    print("Lime Reports has been generated")
    return limeplt_list