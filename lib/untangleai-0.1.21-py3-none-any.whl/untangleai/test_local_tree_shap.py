import pandas as pd
import pickle
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

from algorithms.shap import TreeExplainer, SaveHTML

model = pickle.load(open('../model/model.pkl','rb'))

X = pd.read_csv('../data/X.csv')
y = pd.read_csv('../data/y.csv')
train_X = pd.read_csv('../data/train_X.csv')
train_y = pd.read_csv('../data/train_y.csv')
val_X = pd.read_csv('../data/val_X.csv')
val_y = pd.read_csv('../data/val_y.csv')

# Initializing Explainer
explainer = TreeExplainer(model)

# Instantiating SaveHTML
plotter = SaveHTML()

# Fitting explainer for one testing instance
shap_values = explainer.shap_localexplanation(val_X.iloc[0,:])
local_explainer = plotter.shap_force_plot(explainer.explainer.expected_value[1], shap_values[1], val_X.iloc[0,:])
# plt.savefig('wrapper_reports/local/local_explainer1.pdf', format='pdf', dpi=1000, bbox_inches='tight')
plotter.shap_save_html('reports/local/local_tree_explainer.html', local_explainer)

# Fitting explainer for complete test dataset
shap_values = explainer.shap_localexplanation(val_X)
local_explainer = plotter.shap_force_plot(explainer.explainer.expected_value[1], shap_values[1], val_X)
plotter.shap_save_html('reports/local/local_tree_explainer_complete_dataset.html', local_explainer)

# Global Feature Explanation
shap_values = explainer.shap_localexplanation(val_X)
global_explaner = explainer.shap_globalexplanation(shap_values[1], val_X, show=False)
plt.savefig('reports/global/global_tree_explainer.pdf', format='pdf', dpi=1000, bbox_inches='tight')

