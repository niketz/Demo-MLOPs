from untangleai.algorithms.eli5.process_data import process_data

def run_eli5_explanation(config_path="params.yaml"):
    top, least, all_imp = process_data(config_path)
    print("ELI5 Reports has been generated")
    return top, least, all_imp