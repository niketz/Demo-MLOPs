from untangleai.algorithms.whatif.process_data import process_data

def run_whatif_explanation(config_path="params.yaml"):
    process_data(config_path)
    print("Whatif I-Plot has been generated")
    return None