from algorithms.shap.shap_wrapper import KernelExplainer
import pandas as pd
import pickle
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

from algorithms.shap import TreeExplainer, SaveHTML, AddModels, KernelExplainer

model1 = pickle.load(open('../model/model.pkl','rb'))
model2 = pickle.load(open('../model/model.pkl','rb'))

X = pd.read_csv('../data/X.csv')
y = pd.read_csv('../data/y.csv')
train_X = pd.read_csv('../data/train_X.csv')
train_y = pd.read_csv('../data/train_y.csv')
val_X = pd.read_csv('../data/val_X.csv')
val_y = pd.read_csv('../data/val_y.csv')

plotter = SaveHTML()

# exp_list = []
# def add_model(exp):
#     exp_list.append(exp)
#     return exp_list

# Initializing Explainer
rf_explainer = TreeExplainer(model1)
dt_explainer = KernelExplainer(model1.predict_proba, train_X)
# explainer = add_model(exp=rf_explainer)
# explainer = add_model(exp=dt_explainer, def_list=explainer)

exps = AddModels()
explainer = exps.add_model(rf_explainer, 'rf')
explainer = exps.add_model(dt_explainer, 'dt', def_list=explainer)

exps.shap_explanation(explainer=explainer, data=val_X.iloc[0,:], target_class=1)

# i=1
# data=val_X.iloc[0,:]
# target_class=1
# shap_values = explainer[i].shap_localexplanation(data)
# local_explainer = plotter.shap_force_plot(explainer[i].explainer.expected_value[target_class], 
#                                                     shap_values[target_class], data)
# plotter.shap_save_html('reports/local/local_tree_explainer'+str(i)+'.html', local_explainer)

# def shap_explanation(explainer, data, target_class):
#     for i, value in enumerate(explainer):
#         shap_values = explainer[i].shap_localexplanation(data)
#         local_explainer = plotter.shap_force_plot(explainer[i].explainer.expected_value[target_class], 
#                                                     shap_values[target_class], data)
#         plotter.shap_save_html('reports/local/local_tree_explainer'+'model_'+str(i)+'.html', local_explainer)

# shap_explanation(explainer, val_X.iloc[0,:], 1)
