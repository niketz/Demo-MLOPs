import sys
from untangleai.algorithms.eda.eda import process_data
from flask import Flask, Response, render_template, redirect, send_from_directory
import os
#import untangleai as uai

# config_path = "params.yaml"

def run_eda_explanation(config_path="params.yaml"):
    num_var, num_obs, train_obs, test_obs, model_name, operation_type, tgt_name, features, class_names = process_data(config_path)
    print('EDA Reports have been generated')
    return num_var, num_obs, train_obs, test_obs, model_name, operation_type, tgt_name, features, class_names
