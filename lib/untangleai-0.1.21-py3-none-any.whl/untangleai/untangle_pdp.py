from untangleai.algorithms.pdpbox.process_data import process_data

def run_pdpbox_explanation(config_path="params.yaml"):
    pdpplt_list = process_data(config_path)
    print("PDP Box Reports has been generated")
    return pdpplt_list