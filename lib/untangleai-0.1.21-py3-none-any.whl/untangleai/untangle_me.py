import sys
from untangleai.algorithms.shap.preprocess_data import *
from flask import Flask, Response, render_template, redirect, send_from_directory
import os
#import untangleai as uai

# config_path = "params.yaml"

def run_explanation(config_path="params.yaml"):
    # preprocess_data(config_path)
    # print('Reports have been generated')
    
    cwd = os.getcwd()
    print(cwd)
    curr_path = os.path.join(cwd,"reports") 
    local_path = os.path.join(cwd,"reports","local") 
    static_folder = os.path.join(cwd,"reports","static")
    app = Flask(__name__, template_folder=curr_path, static_folder=static_folder)
    print(app.template_folder)

    @app.route("/")
    def main():
        return render_template('templates/index.html')

    @app.route("/local_one_data/")
    def local_one_data():
        return render_template('local/local_tree_explainer_one_dataRandomForest.html')
    @app.route("/local_complete_data/")
    def local_complete_data():
        return render_template('local/local_tree_explainer_complete_data_RandomForest.html')
    
    @app.route("/global/")
    def main_global():
        filepath = curr_path + '/global/'
        print(filepath)
        return send_from_directory(filepath, 'super.pdf')

    app.run(port=8000)
    # uai.algorithms.shap.preprocess_data(config_path)
    # print('Reports have been generated')



# if __name__ == "__main__":
#     run_explanation(sys.argv[0])
