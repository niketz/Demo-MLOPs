from untangleai.untangle_shap import run_shap_explanation
from untangleai.untangle_eli5 import run_eli5_explanation
from untangleai.untangle_pdp import run_pdpbox_explanation
from untangleai.untangle_lime import run_lime_explanation
from untangleai.untangle_eda import run_eda_explanation
import jinja2
import os
import yaml

template_path = os.path.join(os.getcwd(),'untangleai')
env = jinja2.Environment(loader=jinja2.FileSystemLoader(searchpath=template_path))
template = env.get_template('template.html')


def comp_impfeat(top, imp_shap_feat):
	d = {}
	permimp = top
	shapimp = imp_shap_feat
	for index, value in enumerate(permimp):
		if value in d.keys():
			d[value] = d[value] + (len(permimp)-index)*0.5
		else:
			d[value]=(len(permimp)-index)*0.5

	for index, value in enumerate(shapimp):
		if value in d.keys():
			d[value] = d[value] + (len(shapimp)-index)*0.5
		else:
			d[value]=(len(shapimp)-index)*0.5

	new_ls = sorted(d.items(), key=lambda kv:(kv[1], kv[0]), reverse=True)
	# print(new_ls)  

	feat = []
	for each in new_ls:
		feat.append(each[0])
	# print(feat)
	# print(feat[0:5])
	return(feat[0:5])

def update_data(ls):
	if len(ls)<5:
		diff = 5 - len(ls)
		for i in range(diff):
			ls.append('-----')
	return ls

def generate_report():

	num_var, num_obs, train_obs, test_obs, model_name, operation_type, tgt_name, features, class_names = run_eda_explanation()
	operation_type = operation_type.capitalize()
	top, least, all_imp = run_eli5_explanation()
	top = update_data(top)
	least = update_data(least)
	pdpplt_list = run_pdpbox_explanation()
	shapplt_list, imp_shap_feat, shaploc_plt_list = run_shap_explanation()
	limeplt_list = run_lime_explanation()

	impfeat = comp_impfeat(top, imp_shap_feat)

	html = template.render(num_var=num_var, num_obs=num_obs, train_obs=train_obs, test_obs=test_obs,
							model_name=model_name, operation_type=operation_type,
							tgt_name=tgt_name, features=features, class_names=class_names,
							most_imp=top, least_imp=least, all_imp=all_imp, pdp_list = pdpplt_list, 
							shap_list = shapplt_list, imp_shap_feat=imp_shap_feat, lime_list = limeplt_list,
							shap_loc_list = shaploc_plt_list, impfeat=impfeat)
	
	# run_lime_explanation()
	report_path = os.path.join(os.getcwd(),'reports','reports.html')
	with open(report_path, 'w') as f:
		print('Report Generation Completed')
		f.write(html)

	

if __name__ == "__main__":

	# experiments = get_data(config_path="params.yaml")

	# for each in experiments.keys():
	generate_report()

