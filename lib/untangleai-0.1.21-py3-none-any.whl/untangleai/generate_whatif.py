from untangleai.untangle_whatif import run_whatif_explanation
import jinja2
import os
import yaml

if __name__ == "__main__":

    run_whatif_explanation()

    print('I-Plot has been generated')


